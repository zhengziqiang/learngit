
clc;
clear;

KAData='KA Data--2016.03.xlsx';
KADataBLSheet='raw data';
KAGroupName='European Q.H.';

format LONGG;
[number,text,raw]=xlsread(KAData,KADataBLSheet);

% �ҳ�KAGroupNameȫ������
id = zeros(0,1);
for i=1:size(raw,1)
    if strcmp(raw{i,17},KAGroupName)
        id(end+1) = i;
    end
end
for i=1:size(id,2)
    for j=1:size(raw,2)
        rawKAGroup{i,j} = raw{id(1,i),j};
    end
end
% �ҳ�ȫ��BL no.
BLnoA=zeros(0,1);
for i=1:size(rawKAGroup,1)
    BLnoA(end+1) = str2num(rawKAGroup{i,3});
end
BLnoU=unique(BLnoA);
% �ҳ�ȫ��Material Group
for i=1:size(BLnoU,2)
    
