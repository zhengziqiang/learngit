#!/usr/bin/python

import openpyxl

KAData='KA Data--2016.03.xlsx'
KADataBLSheet='raw data'
KAGroupName='European Q.H.'

wb=openpyxl.load_workbook(filename=KAData, use_iterators=True)
ws=wb.get_sheet_by_name(KADataBLSheet)
it=ws.iter_rows()
for j in next(it):
    print(j.value)

